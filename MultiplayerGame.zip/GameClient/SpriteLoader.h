#pragma once
#include <SFML/Graphics.hpp>
#include <string>

class C_SpriteLoader
{
private:
	class Sprite
	{
	public:
		sf::Texture texture;
		sf::Sprite sprite;
	};

	std::map<std::string, Sprite> spriteMap;

public:
	C_SpriteLoader();
	~C_SpriteLoader();

	sf::Sprite* const getSprite(const std::string& fileName);
};

