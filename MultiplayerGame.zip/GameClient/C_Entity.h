#pragma once
#include <queue>
#include "Global.h"
#include "Packets.h"
#include "C_RenderComponent.h"

struct HitMarker
{
	float timer;
	const u8 damage;

	HitMarker(const u8 damage)
		: damage(damage), timer(0.8f)
	{

	}
};

class C_Entity : public Render::C_RenderComponent
{
public:
	Vec2<u16> position;
	u8 rotation = 0;

private:
	const u16 m_uid;
	EntityType m_entityType;
	std::queue<Vec2<u16>> m_waypoints;
	Vec2<u16> m_from;

	float m_moveTimer;
	bool m_translating;
	// Speed -> Tiles/Tick
	// 1 -> 0.5
	// 2 -> 1
	// 4 -> 2
	// 8 -> 4
	u8 m_speed = 4;

	sf::Sprite* m_sprite_body;
	sf::Sprite* m_sprite_bodyPointer;

public:
	bool expired;
	float deathAnimation;
	CombatState combatState;
	std::deque<HitMarker> hitMarkers;

public:
	C_Entity(const u16 uid, const EntityType entityType, const Vec2<u16> pos);
	~C_Entity();

	u16 getUID() const;
	const EntityType getEntityType() const;

	void update(const GameTime& gameTime); // 60 times/sec
	void render(sf::RenderWindow& window, const GameTime& gameTime) override;

private:
	
};

