#pragma once
#include <string>
#include <Global.h>
#include <SFML/Graphics.hpp>

namespace Render
{
	class C_RenderComponent
	{
	public:
		int uid;
		bool enabled;

	protected:

	public:
		C_RenderComponent();
		~C_RenderComponent();

		virtual const std::string& getDescription() const;
		virtual void render(sf::RenderWindow& window, const GameTime& gameTime) = 0;

	protected:
		sf::Sprite* const getSprite(const std::string& fileName);
	};
}