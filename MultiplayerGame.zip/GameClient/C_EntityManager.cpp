#include "C_EntityManager.h"

C_EntityManager::C_EntityManager()
	: m_thisEntitySlot(0xFFFF)
{
	m_activeEntities.reserve(32);
}

C_EntityManager::~C_EntityManager()
{
	clearEntities();
}

void C_EntityManager::clearEntities()
{
	for (auto iter = m_activeEntities.begin(); iter != m_activeEntities.end(); iter++)
		delete (*iter);
}

void C_EntityManager::removeEntity(const u16 uid)
{
	for (auto iter = m_activeEntities.begin(); iter != m_activeEntities.end(); iter++)
		if ((*iter)->getUID() == uid)
		{
			m_activeEntities.erase(iter);
			return;
		}
}

const std::vector<C_Entity*>& C_EntityManager::getActiveEntities() const
{
	return m_activeEntities;
}

C_Entity* C_EntityManager::getEntity(const u16 uid) const
{
	assert(uid < MAX_ENTITIES);
	for (auto iter = m_activeEntities.begin(); iter != m_activeEntities.end(); iter++)
		if ((*iter)->getUID() == uid)
			return *iter;
	return nullptr;
}

C_Entity* C_EntityManager::getThisEntity() const
{
	assert(m_thisEntitySlot == 0xFFFF || m_thisEntitySlot < MAX_ENTITIES);
	if (m_thisEntitySlot == 0xFFFF)
		return nullptr;
	else
		return getEntity(m_thisEntitySlot);
}

void C_EntityManager::setThisUID(const u16 uid)
{
	assert(uid < MAX_ENTITIES);
	m_thisEntitySlot = uid;
}

void C_EntityManager::update(const GameTime& gameTime)
{
	for (auto e = m_activeEntities.begin(); e != m_activeEntities.end();)
	{
		auto entity = (*e);
		entity->update(gameTime);
		if (entity->expired)
		{
			e = m_activeEntities.erase(e);
			continue;
		}
		e++;
	}
}

void C_EntityManager::processEntityStatusPacket(const SP_EntityStatus_Elem& packet)
{
	C_Entity* entity = getEntity(packet.uid);
	if (entity == nullptr)
	{
		m_activeEntities.push_back(new C_Entity(packet.uid, packet.entityType, packet.pos));
	}
	else
	{
		entity->position = packet.pos;
	}
}
