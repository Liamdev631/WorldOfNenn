#include "C_Client.h"
#include "RPacket.h"
#include "Packets.h"
#include "Loader.h"

C_Client* g_client;
Loader* g_loader;

C_Client::C_Client()
{
	g_client = this;
	g_loader = new Loader();
	m_connectionState = ConnectionState::Disconnected;
	m_client = make_unique<enetpp::client>();
	m_worldManager = new C_EntityManager();
	m_itemManager = new C_ItemManager();
	m_loader = new Loader();
	m_loader->load();
	m_gui = new C_WindowComponent();
	m_packetBuffer = new WPacket(512);
	m_timer.totalTime = 0;
	m_timer.deltaTime = 0;
}

C_Client::~C_Client()
{

}

void C_Client::start()
{
	printf("Client is looking for server!\n");
	m_client->connect(enetpp::client_connect_params()
		.set_channel_count(1)
		.set_server_host_name_and_port(SERVER_IP, 801));
	m_connectionState = ConnectionState::SayingHello;
	//m_gui->loadResources();
}

bool C_Client::update()
{
	//float dt = m_clock.getElapsedTime().asSeconds();
	//m_clock.restart();
	//m_timer.addDeltaTime(dt);

	if (!m_client.get()->is_connecting_or_connected())
		return true;

	// Consume events raised by worker thread
	auto on_connected = [&]() { onConnect(); };
	auto on_disconnected = [&]() { onDisconnect(); };
	auto on_data_received = [&](const u8* data, size_t size) {
		onDataRecieved(data, size);
	};
	m_client->consume_events(on_connected, on_disconnected, on_data_received);

	if (!m_gui->update(m_timer))
		return false;

	m_worldManager->update(m_timer);

	// END GAME LOGIC

	// Send the packet buffer
	if (m_packetBuffer->getBytesWritten() > 0)
	{
		m_client->send_packet(0, m_packetBuffer->getData(), m_packetBuffer->getBytesWritten(), ENET_PACKET_FLAG_RELIABLE);
		m_packetBuffer->reset();
	}

	// Render
	m_gui->render(m_timer);

	//Sleep(1000 / 60);

	return true;
}

void C_Client::stop()
{
	m_client->disconnect();
}

C_EntityManager& C_Client::getEntityManager() const
{
	return *m_worldManager;
}

C_SpriteLoader& C_Client::getSpriteLoader()
{
	return m_spriteLoader;
}

C_WindowComponent& C_Client::getGUIManager() const
{
	return *m_gui;
}

C_ItemManager& C_Client::getItemManager() const
{
	return *m_itemManager;
}

Loader& C_Client::getLoader() const
{
	return *m_loader;
}

WPacket& C_Client::getPacket() const
{
	return *m_packetBuffer;
}

const Inventory& C_Client::getPlayerInventory() const
{
	return m_inventory;
}

void C_Client::onConnect()
{
	printf("Client connected to server!\n");
	m_connectionState = ConnectionState::Connected;
}

void C_Client::onDisconnect()
{
	printf("Client disconnected from server!\n");
}

void C_Client::onDataRecieved(const u8* data, size_t size)
{
	m_entityMutex.lock();
	RPacket packet = RPacket(data, size);
	while (packet.getBytesRead() < packet.getSize())
	{
		const u8 header = packet.peek<u8>();
		//printf("Recieved: packet_header:%u\n", header);
		processPacket(header, packet);
	}

	m_entityMutex.unlock();
}

void C_Client::processPacket(const u8 header, RPacket &packet)
{
#if LOG_PACKET_HEADERS
	printf("\n");
#endif

	switch (header)
	{
		case 0x00:
		{
			// 'Hello' Packet
			const SP_Hello* p = packet.read<SP_Hello>();
#if LOG_PACKET_HEADERS
			printf("Processing P_Hello. uid:%u time:%u\n", p->uid, p->timestamp);
#endif
			m_connectionState = ConnectionState::Connected;
			m_worldManager->setThisUID(p->uid);
			m_timer.totalTime = p->timestamp;
			//m_inventory.deserialize(packet);
			break;
		}

		case 0x01:
		{
			// Entity Status
			const SP_EntityStatus* p = packet.read<SP_EntityStatus>();
#if LOG_PACKET_HEADERS
			printf("Processing P_EntityStatus. entities:%u\n", p->numEntities);
#endif
			assert(p->numEntities >= 1);
			for (int i = 0; i < p->numEntities; i++)
			{
				const SP_EntityStatus_Elem* p2 = packet.read<SP_EntityStatus_Elem>();
				m_worldManager->processEntityStatusPacket(*p2);
#if LOG_PACKET_HEADERS
				printf("Processing P_EntityStatus_Elem elem:%u uid:%#06x type:%#04x pos:(%#06x,%#06x)\n", i, p2->uid, p2->entityType, p2->pos.x, p2->pos.y);
#endif
			}
			break;
		}

		case 0x02:
		{
			// Remove entity
			const SP_RemoveEntity* p = packet.read<SP_RemoveEntity>();
			m_worldManager->removeEntity(p->uid);
#if LOG_PACKET_HEADERS
			printf("Processing P_RemoveEntity. uid:%u\n", p->uid);
#endif
			break;
		}

		case 0x03:
		{
			// Inventory
			const SP_Inventory* p = packet.read<SP_Inventory>();
			m_inventory.deserialize(packet);
#if LOG_PACKET_HEADERS
			printf("Processing P_Inventory. inventory: \n");
#endif
			break;
		}

		case 0x4:
		{
			// Entity took damage
			const SP_EntityTookDamage* p = packet.read<SP_EntityTookDamage>();
#ifdef LOG_PACKET_HEADERS
			printf("Processing P_EntityTookDamage. defender:%u damage:%u health:%u/%u dead:%s\n", p->defender, p->damage, p->combatState.currentHealth, p->combatState.maxHealth, p->combatState.dead ? "yes" : "no");
#endif
			C_Entity* defenderEntity = m_worldManager->getEntity(p->defender);
			if (defenderEntity == nullptr)
				break;
			defenderEntity->combatState = p->combatState;
			defenderEntity->hitMarkers.push_back(HitMarker(p->damage));
			break;
		}

		case 0x05:
		{
			const SP_ItemPicked* p = packet.read<SP_ItemPicked>();
#ifdef LOG_PACKET_HEADERS
			printf("Processing P_ItemPicked. item:%u count:%u\n", p->item.stack.type, p->item.stack.count);
#endif
			m_itemManager->pickItem(p->item);
			break;
		}

		case 0x06:
		{
			const SP_ItemDropped* p = packet.read<SP_ItemDropped>();
#ifdef LOG_PACKET_HEADERS
			printf("Processing P_ItemDropped. item:%s count:%u pos:(%u,%u)\n", g_loader->getItemName(p->item.stack.type).c_str(), p->item.stack.count, p->item.pos.x, p->item.pos.y);
#endif
			m_itemManager->dropItem(p->item);
			break;
		}

		case 0x07:
		{
			const SP_EntityMoved* p = packet.read<SP_EntityMoved>();
			auto entity = m_worldManager->getEntity(p->uid);
			assert(entity != nullptr);
			entity->position = p->pos;
			entity->rotation = p->rotation;
			break;
		}

		default:
			printf("Unknown packet type detected!\n");
			break;
	}
}

