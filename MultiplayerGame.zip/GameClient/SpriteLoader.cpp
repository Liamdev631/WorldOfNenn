#include "SpriteLoader.h"

C_SpriteLoader::C_SpriteLoader()
{
	getSprite("graphics/entities/entity_player.png")->setOrigin(10, 10);
	getSprite("graphics/entities/entity_pointer.png")->setOrigin(0, 1);
}

C_SpriteLoader::~C_SpriteLoader()
{
	//for (auto iter = spriteMap.begin(); iter != spriteMap.end(); iter++)
	//	delete (*iter).second.first;
}

sf::Sprite* const C_SpriteLoader::getSprite(const std::string& fileName)
{
	auto sprite = spriteMap.find(fileName);
	if (sprite == spriteMap.end())
	{
		// Load the sprite
		//spriteMap[fileName]
		auto& newSprite = spriteMap[fileName];
		newSprite.texture.loadFromFile(fileName);
		newSprite.sprite.setTexture(newSprite.texture);
		return &newSprite.sprite;
	}
	return &sprite->second.sprite;
}
