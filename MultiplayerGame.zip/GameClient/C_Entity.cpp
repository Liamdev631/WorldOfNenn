 #include "C_Entity.h"

C_Entity::C_Entity(const u16 uid, const EntityType entityType, const Vec2<u16> pos)
	: m_uid(uid), m_entityType(entityType), m_moveTimer(0), m_translating(false), expired(false)
{
	m_from = pos;
	deathAnimation = 1.0f;

	m_sprite_body = getSprite("graphics/entities/entity_player.png");
	m_sprite_bodyPointer = getSprite("graphics/entities/entity_pointer.png");
}

C_Entity::~C_Entity()
{

}

u16 C_Entity::getUID() const
{
	return m_uid;
}

const EntityType C_Entity::getEntityType() const
{
	return m_entityType;
}

void C_Entity::update(const GameTime& gameTime)
{
	// Decrement hit marker timers
	for (size_t i = 0; i < hitMarkers.size(); i++)
		if (gameTime.deltaTime > hitMarkers[i].timer)
			hitMarkers[i].timer = 0;
		else
			hitMarkers[i].timer -= gameTime.deltaTime;
	while (hitMarkers.size() > 0 && hitMarkers.front().timer == 0)
		hitMarkers.pop_front();

	// Decrement death timer
	if (combatState.dead)
	{
		if (gameTime.deltaTime >= deathAnimation)
			expired = true;
		else
			deathAnimation -= gameTime.deltaTime;
		return;
	}
}

void C_Entity::render(sf::RenderWindow& window, const GameTime& gameTime)
{
	m_sprite_body->setPosition(position.x * 20.f, position.y * 20.f);
	m_sprite_bodyPointer->setPosition(m_sprite_body->getPosition());
	m_sprite_bodyPointer->setRotation(rotation);

	window.draw(*m_sprite_body);
	window.draw(*m_sprite_bodyPointer);
}
