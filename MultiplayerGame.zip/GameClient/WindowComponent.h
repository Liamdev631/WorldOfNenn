#pragma once
#include "Global.h"
#include <vector>
#include <SFML/Graphics.hpp>
#include "C_RenderComponent.h"

#define DEFAULT_WINDOW_SIZE Vec2s(1280, 720)

class C_WindowComponent
{
private:
	Vec2s windowSize;

	// A list of all the components to call ->render() on
	// Do not clear this anywhere other than the clearRenderComponents() function
	std::vector<Render::C_RenderComponent*> m_renderComponents;

	std::unique_ptr<sf::RenderWindow> window;

public:
	C_WindowComponent();
	~C_WindowComponent();

	bool update(const GameTime& gameTime);
	void render(const GameTime& gameTime);

	void addRenderComponent(Render::C_RenderComponent* comp);
	void removeRenderComponent(Render::C_RenderComponent* comp);
};

