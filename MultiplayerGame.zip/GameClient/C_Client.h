#pragma once
#include "Global.h"
#include <enetpp\client.h>
#include "WPacket.h"
#include "C_EntityManager.h"
#include "C_ItemManager.h"
//#include "C_GUI.h"
#include "Loader.h"
#include "Items.h"
#include "WindowComponent.h"
#include "SpriteLoader.h"

#define SERVER_IP "localhost"
#define LOG_PACKET_HEADERS false

class WPacket;
class C_WindowComponent;

enum ConnectionState
{
	Disconnected,
	SayingHello,
	Connected
};

class C_Client
{
private:
	ConnectionState m_connectionState;
	std::unique_ptr<enetpp::client> m_client;
	C_EntityManager* m_worldManager;
	C_ItemManager* m_itemManager;
	C_WindowComponent* m_gui;
	Loader* m_loader;
	std::mutex m_entityMutex;
	WPacket* m_packetBuffer;
	GameTime m_timer; // For local timing
	//sf::Clock m_clock;
	Inventory m_inventory;
	C_SpriteLoader m_spriteLoader;

public:
	C_Client();
	~C_Client();

	C_EntityManager& getEntityManager() const;
	C_WindowComponent& getGUIManager() const;
	C_ItemManager& getItemManager() const;
	C_SpriteLoader& getSpriteLoader();
	Loader& getLoader() const;
	WPacket& getPacket() const;
	const Inventory& getPlayerInventory() const;

	// Initializes recources required for the game, including networking.
	void start();
	
	// Runs a standard game update.
	// @return: true if the game should continue running. False otherwise.
	bool update();	// 60 times/sec, variable

	// Abruptly stops networking and deletes managed recources
	void stop();

private:
	void onConnect();
	void onDisconnect();
	void onDataRecieved(const u8* data, size_t size);
	void processPacket(const u8 header, RPacket &packet);
};

extern C_Client* g_client;
