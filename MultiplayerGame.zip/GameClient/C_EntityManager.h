#pragma once
#include "Global.h"
#include <vector>
#include "C_Entity.h"
#include "RPacket.h"
#include "Packets.h"

class C_EntityManager
{
private:
	std::vector<C_Entity*> m_activeEntities;
	u16 m_thisEntitySlot;

public:
	C_EntityManager();
	~C_EntityManager();

	// Clears the entity list
	void clearEntities();

	// Removes and entity from the entity list
	void removeEntity(const u16 uid);

	// Returns a list of all the loaded entities
	const std::vector<C_Entity*>& getActiveEntities() const;

	// Returns an entity with a given uid
	C_Entity* getEntity(const u16 uid) const;

	// Returns the Entity representing this player
	C_Entity* getThisEntity() const;

	// Sets the uid of this player, given by the server
	void setThisUID(const u16 uid);

	// Runs an update of the EntityManager
	void update(const GameTime& gameTime);

	void processEntityStatusPacket(const SP_EntityStatus_Elem& packet);

private:
};

