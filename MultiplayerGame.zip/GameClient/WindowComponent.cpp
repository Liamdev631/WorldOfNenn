#include "WindowComponent.h"

C_WindowComponent::C_WindowComponent()
	: windowSize(DEFAULT_WINDOW_SIZE)
{
	window = std::make_unique<sf::RenderWindow>(sf::VideoMode(DEFAULT_WINDOW_SIZE.x, DEFAULT_WINDOW_SIZE.y), "World of Nenn");
}

C_WindowComponent::~C_WindowComponent()
{

}

bool C_WindowComponent::update(const GameTime& gameTime)
{
	sf::Event event;
	while (window->pollEvent(event))
	{
		// "close requested" event: we close the window
		if (event.type == sf::Event::Closed)
			window->close();
	}
	return true;
}

int counter = 0;
void C_WindowComponent::render(const GameTime& gameTime)
{
	window->clear(sf::Color::Green);

	for (auto iter = m_renderComponents.begin(); iter != m_renderComponents.end(); iter++)
		if ((*iter)->enabled)
			(*iter)->render(*window.get(), gameTime);

	window->display();
}

void C_WindowComponent::addRenderComponent(Render::C_RenderComponent* comp)
{
	m_renderComponents.push_back(comp);
	comp->uid = rand();
}

void C_WindowComponent::removeRenderComponent(Render::C_RenderComponent* comp)
{
	for (auto iter = m_renderComponents.begin(); iter != m_renderComponents.end(); iter++)
		if (*iter == comp)
		{
			m_renderComponents.erase(iter);
			return;
		}
}
