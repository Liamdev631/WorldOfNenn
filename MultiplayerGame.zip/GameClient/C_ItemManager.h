#pragma once
#include "Global.h"
#include <vector>
#include "Items.h"

class C_ItemManager
{
private:
	std::vector<DropableItem> m_items;

public:
	C_ItemManager();
	~C_ItemManager();

	void pickItem(const DropableItem& item);
	void dropItem(const DropableItem& item);
	std::vector<DropableItem>& getItemsList();
};

