#pragma once
#include <enetpp\global_state.h>
#include "C_Client.h"

class Main
{
public:
	Main()
	{
		m_client = make_unique<C_Client>();
	}

	~Main()
	{
		forceStop();
	}

	void start()
	{
		enetpp::global_state::get().initialize();
		m_client->start();
	}

	bool update()
	{
		return m_client->update();
	}

	void forceStop()
	{
		m_client->stop();
		enetpp::global_state::get().deinitialize();
	}


private:
	unique_ptr<C_Client> m_client;
};

int main()
{
	srand((unsigned int)time(NULL));
	Sleep(100);

	Main m;
	m.start();
	while (m.update()) {  }
	m.forceStop();

	return 0;
}
