#include "S_Entity.h"
#include <assert.h>
#include "S_GlobalServer.h"
#include "S_Connection.h"


/// Constructor
S_Entity::S_Entity(const u16 uid, const EntityType entityType, const Region region)
	: m_id(uid), m_entityType(entityType), m_combatComponent(*this), m_movementComponent(*this), m_connection(nullptr)
{
	m_movementComponent.region = region;
}

/// Deconstructor
S_Entity::~S_Entity()
{

}

void S_Entity::tick()
{
	if (m_combatComponent.combatState.dead)
		return;

	m_movementComponent.tick();
}

const u16& S_Entity::getUID() const
{
	return m_id;
}

const EntityType& S_Entity::getEntityType() const
{
	return m_entityType;
}

S_Connection& S_Entity::getConnection() const
{
	return *m_connection;
}

S_CombatComponent& S_Entity::getCombatComponent()
{
	return m_combatComponent;
}

S_MovementComponent& S_Entity::getMovementComponent()
{
	return m_movementComponent;
}

void S_Entity::onRespawn()
{
	m_movementComponent.setPosition(Vec2s(20, 20));
}

void S_Entity::onDeath()
{
	// Drop bones
	auto& thisRegion = m_movementComponent.getRegion();
	thisRegion.addGroundItem(DropableItem(ItemStack(ITEM_BONES, 1), m_movementComponent.getPosition()));
}
