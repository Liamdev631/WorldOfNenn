#pragma once
#include "S_Server.h"
extern S_Server* g_server;