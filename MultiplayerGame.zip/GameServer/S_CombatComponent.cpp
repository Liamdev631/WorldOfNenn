#include "S_CombatComponent.h"
#include "S_Entity.h"
#include "S_GlobalServer.h"

// NPCHandler.java 1917 applyDamage()

S_CombatComponent::S_CombatComponent(S_Entity& owner)
	: m_owner(owner), isInCombat(false), justDied(false), attackTimer(0), respawnTimer(1)
{
	combatState = CombatState(4);
	attackSpeed = 6;
	maxHitMelee = 4;
	respawnDelay = 16;
}

S_CombatComponent::~S_CombatComponent()
{

}

void S_CombatComponent::tick()
{
	if (combatState.dead)
	{
		if (respawnTimer-- == 0)
		{
			combatState.reset();
			m_owner.onRespawn();
			m_owner.getMovementComponent().forcePositionUpdate();
		}
	}

	if (attackTimer > 0)
		attackTimer--;
	if (!isInCombat)
		return;
	if (attackTimer != 0)
		return;

	if (inRange(*target))
	{
		// Attack
		attackTimer = attackSpeed;
		u8 damage = 0;
		if ((unsigned int)(rand()) % 1024 < 630)
			if (maxHitMelee == 1)
				damage = 1;
			else
				damage = 1 + rand() % (maxHitMelee - 1);

		// Deal damage
		target->getCombatComponent().takeDamage(*this, damage);

		// Stop combat if dead
		if (target->getCombatComponent().combatState.dead)
		{
			m_owner.getMovementComponent().resetMovement();
			isInCombat = false;
		}
	}
}

void S_CombatComponent::attackTarget(S_Entity& newTarget)
{
	//if (!isMulticombat)
	//	if (isInCombat)
	//		return;
	//	if (newTarget->getCombatComponent().isInCombat)
	//		return;
	//}

	target = &newTarget;
	isInCombat = true;
	m_owner.getMovementComponent().startFollow(*target);
}

void S_CombatComponent::takeDamage(S_CombatComponent& attacker, u8 damage)
{
	if (combatState.dead)
		return;

	//if (target->autoRetaliate)
	if (!isInCombat)
		attackTarget(attacker.m_owner);

	auto et = m_owner.getEntityType();
	if (et != ET_PLAYER && et != ET_ADMIN) // Temp make playesr immune to damage
	{
		if (damage >= combatState.currentHealth)
		{
			// Entity has no health left
			combatState.currentHealth = 0;
			combatState.dead = true;
			justDied = true;
			respawnTimer = respawnDelay;

			isInCombat = false;
			attacker.isInCombat = false;

			m_owner.getMovementComponent().resetMovement();
			target->getMovementComponent().resetMovement();
			m_owner.onDeath();
		}
		else
			// Take damage
			combatState.currentHealth -= damage;
	}
	// Tell nearby players about the hit
	//auto playersList = g_server->getPlayers();
	auto& connectionList = m_owner.getMovementComponent().getRegion().getConnections();
	for (auto& conn : connectionList)
	{
		auto& buffer = conn.second->getBuffer();
		buffer.write<u8>(0x11);
		buffer.write<u16>(m_owner.getUID());
		buffer.write<u8>(damage);
		buffer.write<CombatState>(combatState);
	}
}

u8 S_CombatComponent::getRange() const
{
	return m_owner.getEntityType() == ET_PLAYER ? 1 : 1;
}

bool S_CombatComponent::inRange(S_Entity& other) const
{
	return m_owner.getMovementComponent().isWithinDistance(other.getMovementComponent().getPosition(), getRange());
}

void S_CombatComponent::reset()
{
	hits.clear();
	justDied = false;
}

void S_CombatComponent::totalReset()
{
	reset();
	combatState.reset();
}
