#include "S_MovementComponent.h"
#include "S_GlobalServer.h"
#include "S_Region.h"
#include "S_Entity.h"

S_MovementComponent::S_MovementComponent(S_Entity& owner)
	: m_owner(owner), m_moveState(MoveState::Idle), m_hasMoved(false), m_moveTimer(0)
{

}

S_MovementComponent::~S_MovementComponent()
{

}

void S_MovementComponent::tick()
{
	// Update position
	switch (m_moveState)
	{
		case MoveState::Idle:
		{
			// Do nothing
			break;
		}

		case MoveState::Waypoint:
		{
			if (m_moveTimer++ != m_speed)
				break;
			m_moveTimer = 0;

			// Advance towards the next waypoint
			stepTowards(m_waypoints.front());
			if (m_waypoints.front() == m_position)
				m_waypoints.pop();

			// Set state to IDLE if we have reached the last waypoint
			if (m_waypoints.size() == 0)
				resetMovement();
			break;
		}

		case MoveState::Follow:
		{
			if (m_followEntity == nullptr) {
				resetMovement();
				break;
			}

			if (m_moveTimer++ != m_speed)
				break;
			m_moveTimer = 0;

			if (m_followEntity->getMovementComponent().getPosition() == m_position)
			{
				// Step off the target to a random direction
				switch (rand() % 4) {
					case 0: m_position.x += 1; break;
					case 1: m_position.x -= 1; break;
					case 2: m_position.y += 1; break;
					case 3: m_position.y -= 1; break;
				}
				m_hasMoved = true;
				break;
			}
			else
			{
				// Step towards the target
				int followDistance = 1;
				if (m_owner.getCombatComponent().isInCombat)
					followDistance = m_owner.getCombatComponent().getRange();
				if (!isWithinDistance(m_followEntity->getMovementComponent().getPosition(), followDistance))
					stepTowards(*m_followEntity);
			}
		}
	}
}

bool S_MovementComponent::isNear(u16 entity) const
{
	auto otherEntity = g_server->getWorldManager().getEntity(entity);
	assert(&otherEntity != nullptr);
	return isNear(*otherEntity);
}

bool S_MovementComponent::isNear(S_Entity& entity) const
{
	const Vec2s& entityPos = entity.getMovementComponent().getPosition();
	int deltaX = entityPos.x - m_position.x, deltaY = entityPos.y - m_position.y;
	return deltaX <= 15 && deltaX >= -16 && deltaY <= 15 && deltaY >= -16;
}

bool S_MovementComponent::isNextTo(u16 entity) const
{
	S_Entity* otherEntity = g_server->getWorldManager().getEntity(entity);
	assert(otherEntity != nullptr);
	return isNextTo(*otherEntity);
}

bool S_MovementComponent::isNextTo(S_Entity& entity) const
{
	const Vec2s& entityPos = entity.getMovementComponent().getPosition();
	int deltaX = entityPos.x - m_position.x, deltaY = entityPos.y - m_position.y;
	return deltaX <= 1 && deltaX >= -1 && deltaY <= 1 && deltaY >= -1;
}

bool S_MovementComponent::isWithinDistance(const Vec2s& p, int distance) const
{
	return ((m_position.x - p.x <= distance && m_position.x - p.x >= -distance) &
		(m_position.y - p.y <= distance && m_position.y - p.y >= -distance));
}

const MoveState& S_MovementComponent::getMoveState() const
{
	return m_moveState;
}

const Vec2s& S_MovementComponent::getPosition() const
{
	return m_position;
}

void S_MovementComponent::setPosition(const Vec2s& position)
{
	m_position = position;
}

void S_MovementComponent::resetMovement()
{
	while (m_waypoints.size() > 0)
		m_waypoints.pop();
	m_moveState = MoveState::Idle;
	m_moveTimer = 0;
}

void S_MovementComponent::moveToPosition(const Vec2<u16>& position)
{
	// Fresh movement state
	resetMovement();

	m_moveState = MoveState::Waypoint;
	m_waypoints.push(position);
}

void S_MovementComponent::stepTowards(const Vec2s& target)
{
	if (m_position.x > target.x)
		m_position.x--;
	else if (m_position.x < target.x)
		m_position.x++;

	if (m_position.y > target.y)
		m_position.y--;
	else if (m_position.y < target.y)
		m_position.y++;

	m_hasMoved = true;
}

void S_MovementComponent::stepTowards(S_Entity& target)
{
	stepTowards(target.getMovementComponent().getPosition());
}

void S_MovementComponent::startFollow(u16 entity)
{
	m_moveState = MoveState::Follow;
	m_followEntity = g_server->getWorldManager().getEntity(entity);
}

void S_MovementComponent::startFollow(S_Entity& entity)
{
	m_moveState = MoveState::Follow;
	m_followEntity = &entity;
}

S_Region& S_MovementComponent::getRegion() const
{
	return g_server->getWorldManager().getRegion(region);
}

void S_MovementComponent::reset()
{
	m_hasMoved = false;
	m_forcePositionUpdate = false;
}

bool S_MovementComponent::hasUpdate() const
{
	return m_hasMoved || m_forcePositionUpdate;
}

void S_MovementComponent::forcePositionUpdate()
{
	m_forcePositionUpdate = true;
}
