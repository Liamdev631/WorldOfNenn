#include "S_Connection.h"
#include "S_GlobalServer.h"

S_Connection::S_Connection()
	: m_buffer(new WPacket(512)), m_player(nullptr)
{

}

S_Connection::~S_Connection()
{

}

u32 S_Connection::getUID() const
{
	return m_uid;
}

void S_Connection::set_id(u32 uid)
{
	m_uid = uid;
}

S_Entity& S_Connection::getEntity() const
{
	return *m_player;
}

void S_Connection::setPlayer(S_Entity& player)
{
	if (!m_player)
		m_player = &player;
}

WPacket& S_Connection::getBuffer() const
{
	return *m_buffer;
}

bool S_Connection::attemptPickupItem(const DropableItem& item)
{
	auto region = m_player->getMovementComponent().getRegion();

	bool takeItem = false;

	// First, try to take the item from the world
	for (auto iter = region.getItems().begin(); iter != region.getItems().end(); iter++)
		if ((*iter).stack.type == item.stack.type)
		{
			// If the item was taken, find a suitable spot
			ItemStack newItem = item.stack;
			auto maxStack = g_server->getLoader().getItemMaxStack(newItem.type);
			if (maxStack == 1)
			{
				// Not stackable
				for (int i = 0; i < 28; i++)
					if (inventory.itemStacks[i].count == 0)
					{
						inventory.itemStacks[i] = newItem;
						inventory.itemStacks[i].count = 1;
						inventory.dirty = true;
						takeItem = true;
						break;
					}
			}
			else
			{
				for (int i = 0; i < 28; i++)
				{
					if (inventory.itemStacks[i].type == newItem.type)
					{
						if (inventory.itemStacks[i].count + newItem.count >= maxStack)
						{
							// Not enough room in this stack, but we can take some
							int amountToRemove = maxStack - inventory.itemStacks[i].count;
							newItem.count -= amountToRemove;
							inventory.itemStacks[i].count = maxStack;
							inventory.dirty = true;
							takeItem = true;
						}
						else
						{
							inventory.itemStacks[i].count += newItem.count;
							inventory.dirty = true;
							takeItem = true;
						}
					}
				}
			}

			if (takeItem)
			{
				// Remove the item from the world
				region.getItems().erase(iter);

				// Tell the players
				for (auto iter = region.getConnections().begin(); iter != region.getConnections().end(); iter++)
				{
					WPacket& buffer = iter->second->getBuffer();
					buffer.write<u8>(0x05);
					buffer.write<DropableItem>(item);
				}
			}

			break;
		}

	return takeItem;
}
