#include "S_Server.h"
#include <queue>
#include "WPacket.h"
#include "Packets.h"

S_Server::S_Server()
{
	m_server = make_unique<enetpp::server<S_Connection>>();
	for (int i = 0; i < MAX_PLAYERS; i++)
		m_connections[i] = nullptr;
	m_loginManager = new S_LoginManager();
	m_worldManager = new S_WorldManager();
	m_loadedPlayers.reserve(MAX_PLAYERS);
}

S_Server::~S_Server()
{
	m_server->stop_listening();
}

void S_Server::start()
{
	m_timestamp = 0;

	printf("Listening on port 801.\n");
	auto init_client_func = [&](S_Connection& client, const char* ip) {
		clientInitFunc(client, ip);
	};

	m_server->start_listening(enetpp::server_listen_params<S_Connection>()
		.set_max_client_count(20)
		.set_channel_count(1)
		.set_listen_port(801)
		.set_initialize_client_function(init_client_func));

	m_loader.load();
	printf("Data tables loaded!\n");

	printf("Loading NPCs.\n");
	u16 npcsToAdd = 6;
	for (u16 i = 0; i < npcsToAdd; i++)
		m_worldManager->registerNPC(i, ET_RAT);
	printf("Loaded %u NPCs.\n", npcsToAdd);
}

void S_Server::addConnectedPlayers()
{
	S_Connection* newConnection = m_loginManager->popPlayer();
	while (newConnection)
	{
		m_worldManager->registerPlayer(*newConnection);
		m_loadedPlayers.push_back(newConnection);
		auto& packet = newConnection->getBuffer();
		auto& newEntity = newConnection->getEntity();

		// Send the 'Hello' packet to the new player
		packet.write<u8>(0x00);
		packet.write<u32>(m_timestamp);
		packet.write<u16>(newConnection->getUID());
		newConnection->inventory.serialize(packet);

		// Tell the new player about their surroundings
		P_EntityStatus* addEntitiesPacket = packet.writePacket<P_EntityStatus>(0x01);
		assert(m_worldManager->getEntities().size() <= 0xFF); // More than 255 entities in the players surroundings. Rediculous!
		addEntitiesPacket.numEntities = (u8)m_worldManager->getEntities().size();
		auto& entitiesInRegion = newEntity.getMovementComponent().getRegion().getEntities();
		for (auto iter = entitiesInRegion.begin();
			 iter != entitiesInRegion.end(); iter++)
		{
			auto otherEntity = iter->second;
			packet.write<u16>(otherEntity->getUID());
			packet.write<EntityType>(otherEntity->getEntityType());
			packet.write<Vec2<u16>>(otherEntity->getMovementComponent().getPosition());
		}

		// Tell other players about this new player
		auto& connectionsList = newEntity.getMovementComponent().getRegion().getConnections();
		for (auto iter = connectionsList.begin(); iter != connectionsList.end(); iter++)
		{
			if (iter->second == newConnection)
				continue;
			auto& buffer = iter->second->getBuffer();
			buffer.write<u8>(0x01);
			buffer.write<u8>(1);
			buffer.write<u16>(newEntity.getUID());
			buffer.write<EntityType>(newEntity.getEntityType());
			buffer.write<Vec2<u16>>(newEntity.getMovementComponent().getPosition());
		}

		printf("Client (%d) added as a player.\n", newConnection->getUID());
		newConnection = m_loginManager->popPlayer();
	}
}

void S_Server::disconnectPlayer(S_Connection& connection)
{
	auto iter = std::find(m_loadedPlayers.begin(), m_loadedPlayers.end(), &connection);
	assert(iter != m_loadedPlayers.end());
	m_loadedPlayers.erase(iter);
	m_worldManager->deregisterPlayer(connection);

	// Send a message to the nearby players
	for (iter = m_loadedPlayers.begin(); iter != m_loadedPlayers.end(); iter++)
	{
		auto& buff = (*iter)->getBuffer();
		buff.write<u8>(0x02);
		buff.write<u16>((*iter)->getUID());
	}

	printf("Client (%d) disconnected.\n", connection.getUID());
	m_connections[connection.getUID()] = nullptr;
}

void S_Server::tick()
{
	calculateNewState();

	transmitNewStates();

	// Send the packets
	for (auto c : m_server->get_connected_clients())
		if (c->getBuffer().getBytesWritten() > 0)
		{
			m_server->send_packet_to(c->getUID(), 0, c->getBuffer().getData(), c->getBuffer().getBytesWritten(), ENET_PACKET_FLAG_RELIABLE);
			c->getBuffer().reset();
		}

}

void S_Server::calculateNewState()
{
	// Pull new players from the LoginManager
	addConnectedPlayers();

	// Consume events raised by the network worker thread
	auto on_client_connected = [&](S_Connection& client) { onClientConnected(client); };
	auto on_client_disconnected = [&](S_Connection& client) { onClientDisconnected(client); };
	auto on_client_data_received = [&](S_Connection& client, const u8* data, size_t data_size) {
		onDataRecieved(client, RPacket(data, data_size));
	};
	m_server->consume_events(on_client_connected, on_client_disconnected, on_client_data_received);

	// Calculate new entity positions
	m_worldManager->tick();
}

void S_Server::transmitNewStates()
{
	for (auto conn = m_loadedPlayers.begin(); conn != m_loadedPlayers.end(); conn++)
	{
		S_Connection& player = *(*conn);
		S_Entity& playerEntity = (*conn)->getEntity();
		WPacket& packet = (*conn)->getBuffer();
		S_Region& region = playerEntity.getMovementComponent().getRegion();

		// Send updated positions
		int numEntities = 0;
		std::map<u16, S_Entity*>::iterator entityIter;
		for (entityIter = region.getEntities().begin(); entityIter != region.getEntities().end(); entityIter++)
			if (entityIter->second->getMovementComponent().hasUpdate())
				numEntities++;
		if (numEntities > 0)
		{
			packet.write<u8>(0x01); // P_EntityStatus Header
			packet.write<u8>(numEntities);
			for (entityIter = region.getEntities().begin(); entityIter != region.getEntities().end(); entityIter++)
			{
				auto other = entityIter->second;
				if (other->getMovementComponent().hasUpdate())
				{
					packet.write<u16>(other->getUID());
					packet.write<u16>(other->getEntityType());
					packet.write<Vec2<u16>>(other->getMovementComponent().getPosition());
				}
			}
		}

		// Send updated inventories
		if (player.inventory.dirty)
		{
			player.inventory.dirty = false;
			packet.write<u8>(0x03);
			packet.write<u16>(player.getUID());
			player.inventory.serialize(packet);
		}
	}
}

void S_Server::stop()
{
	m_server->stop_listening();
}

S_WorldManager& S_Server::getWorldManager() const
{
	return *m_worldManager;
}

const Loader& S_Server::getLoader() const
{
	return m_loader;
}

const std::vector<S_Connection*>& S_Server::getPlayers() const
{
	return m_loadedPlayers;
}

void S_Server::clientInitFunc(S_Connection& client, const char* ip)
{
	// Choose a uid for the new client
	u16 index = 0;
	while (m_connections[index]) // TODO: This should be limited by MAX_PLAYERS
		index++;
	m_connections[index] = &client;
	client.set_id(index);
}

/// Called when a client connects to the server
void S_Server::onClientConnected(S_Connection& client)
{
	printf("Client (%u) connected.\n", client.getUID());
	m_loginManager->registerNewConnection(&client);
}

/// Called when a client disconnects from the server
void S_Server::onClientDisconnected(S_Connection& client)
{
	disconnectPlayer(client);
}

/// Called when the server recieves data from a connected client
void S_Server::onDataRecieved(S_Connection& client, RPacket packet)

{
	S_Entity& playerEntity = client.getEntity();
	//printf("Data recieved from client with uid %u, length &u %u\n", client.uid, data_size);
	while (packet.getBytesRead() < packet.getSize())
	{
		const u8 header = *packet.read<u8>();
		switch (header)
		{
			case 0x01:
			{
				// Request to attack
				const P_AttackEntity& p = *packet.read<P_AttackEntity>();
				playerEntity.getCombatComponent().attackTarget(*m_worldManager->getEntity(p.targetUID));
				continue;
			}
			continue;

			case 0x10:
			{
				// Player wants to move to a position
				const Vec2<u16>& pos = *packet.read<Vec2<u16>>();
				playerEntity.getMovementComponent().moveToPosition(pos);
				continue;
			}

			case 0x05:
			{
				// Player wants to pick up an item
				const P_ItemPicked& p = *packet.read<P_ItemPicked>();
				client.attemptPickupItem(p.item);
				continue;
			}

			case 0x06:
			{
				// Player wants to drop an item
				continue;
			}
		}
	}
}
