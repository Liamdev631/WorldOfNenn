#pragma once
#include "S_Entity.h"
#include <queue>
#include "Global.h"
#include "S_CombatComponent.h"
#include "S_MovementComponent.h"

class S_Connection;
class S_Region;

class S_Entity
{
	friend class S_LoginManager;
private:
	S_Connection* m_connection; // nullptr if this is not a player.
	u16 m_id;
	EntityType m_entityType;

protected:
	// Components
	S_CombatComponent m_combatComponent;
	S_MovementComponent m_movementComponent;

public:
	S_Entity(const u16 uid, const EntityType entityType, const Region region);
	~S_Entity();

	/// Called each tick of the server
	virtual void tick();

	//---- Getters / Setters ----//

	/// Returns the unique id of this entity
	const u16& getUID() const;

	/// Returns this entity's type
	const EntityType& getEntityType() const;
	
	/// Returns the Connection attached to this entity, or nullptr if this is not a player
	S_Connection& getConnection() const;
	
	//---- Components ----//
	S_CombatComponent& getCombatComponent();
	S_MovementComponent& getMovementComponent();

	//----- Events ----- //

	/// Called when this entity respawns
	virtual void onRespawn();

	/// Called upon this entity's death
	virtual void onDeath();
};

