#include "S_Region.h"
#include "S_WorldManager.h"
#include "S_Connection.h"
#include "WPacket.h"

S_Region::S_Region(S_WorldManager& worldManager)
	: m_worldManager(worldManager)
{

}

S_Region::~S_Region()
{

}

void S_Region::tick()
{

}

#pragma region Entities

void S_Region::addEntity(S_Entity& entity)
{
	m_entitiesList[entity.getUID()] = &entity;
}

void S_Region::addConnection(S_Connection& connection)
{
	m_connectionsList[connection.getUID()] = &connection;
	m_entitiesList[connection.getUID()] = &connection.getEntity();
}

void S_Region::removeConnection(S_Connection& connection)
{
	m_connectionsList.erase(connection.getUID());
	m_entitiesList.erase(connection.getUID());

}

std::map<u16, S_Entity*>& S_Region::getEntities()
{
	return m_entitiesList;
}

std::map<u16, S_Connection*>& S_Region::getConnections()
{
	return m_connectionsList;
}

#pragma endregion

#pragma region Items

std::vector<DropableItem>& S_Region::getItems()
{
	return m_itemsList;
}

void S_Region::addGroundItem(const DropableItem& item)
{
	m_itemsList.push_back(item);
	for (auto& conn : m_connectionsList)
	{
		auto& buffer = conn.second->getBuffer();
		buffer.write<u8>(0x06);
		buffer.write<DropableItem>(item);
	}
}

bool S_Region::removeGroundItem(const DropableItem& item)
{
	

	return false;
}

#pragma endregion
