#include "S_Entity_NPC.h"
#include "S_GlobalServer.h"

S_Entity_NPC::S_Entity_NPC(const u16 uid, const EntityType entityType, const Region region)
	: S_Entity(uid, entityType, region), m_stepTimer(4)
{
	m_movementComponent.setPosition(Vec2s(2 + rand() % 30, 2 + rand() % 20));
	boundsLocation = m_movementComponent.getPosition();
	boundsSize = Vec2<u8>(3 + rand() % 3, 3 + rand() % 3);

	m_combatComponent.maxHitMelee = 1;
	m_combatComponent.attackSpeed = 10;
}

S_Entity_NPC::~S_Entity_NPC()
{

}

void S_Entity_NPC::tick()
{
	S_Entity::tick();

	if (m_combatComponent.combatState.dead)
		return;

	if (m_movementComponent.getMoveState() == MoveState::Idle)
		m_stepTimer--;
	if (m_stepTimer == 0)
	{
		m_stepTimer = 8 + rand() % 16;
		Vec2<u16> dest = boundsLocation;
		dest.x += rand() % boundsSize.x;
		dest.y += rand() % boundsSize.y;
		m_movementComponent.moveToPosition(dest);
	}
}

void S_Entity_NPC::onRespawn()
{
	Vec2s spawnPoint = boundsLocation;
	spawnPoint.x += rand() % boundsSize.x;
	spawnPoint.y += rand() % boundsSize.y;
	m_movementComponent.setPosition(spawnPoint);
}

void S_Entity_NPC::onDeath()
{
	S_Entity::onDeath();
}
