#pragma once
#include "S_Entity.h"

class S_Entity_NPC : public S_Entity
{
private:
	u8 m_stepTimer;
	Vec2<u16> boundsLocation;
	Vec2<u8> boundsSize;

protected:

public:
	S_Entity_NPC(const u16 uid, const EntityType entityType, const Region region);
	~S_Entity_NPC();

	void tick() override;
	void onRespawn() override;
	void onDeath() override;
};

