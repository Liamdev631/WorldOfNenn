#pragma once
#include "Global.h"
#include <queue>

class S_Region;
class S_Entity;

enum MoveState : u8
{
	Idle = 0, // Make no actions
	Waypoint = 1, // Follow a series of waypoints
	Follow = 2, // Follow a entity until told otherwise
	Combat = 3, // Compelx movement associated with combat
	Guided = 4, // Follow a compelx series of waypoints, possibly with dialogue
};

class S_MovementComponent
{
private:
	S_Entity& m_owner;
	Vec2s m_position;
	MoveState m_moveState;
	S_Entity* m_followEntity;
	std::queue<Vec2<u16>> m_waypoints;
	u8 m_moveTimer;
	u8 m_speed; // # of ticks needed to complete movement

	bool m_hasMoved; // Desribes whether or not the player has changed position this tick
	bool m_forcePositionUpdate; // If this is set to true, all nearby players will recieve a position update for this entity this tick

public:
	Region region;

public:
	S_MovementComponent(S_Entity& owner);
	~S_MovementComponent();

	void tick();

	//void blinkTo(const Vec2s& position);

	/// Returns the movement type of this entity
	const MoveState& getMoveState() const;

	/// Returns the position of the entity this tick
	const Vec2s& getPosition() const;

	void setPosition(const Vec2s& position);

	/// Returns the region where this entity is currently located
	S_Region& getRegion() const;

	/// Resets the movement state of the entity. Sets to IDLE
	void resetMovement();

	/// Called at the beginning of every tick
	void reset();

	/// Returns true if the given entity is within 16 units of this entity
	bool isNear(const u16 entity) const;

	/// Returns true if the given entity is within 16 units of this entity
	bool isNear(S_Entity& entity) const;

	/// Returns true if the given entity is adjacent to this entity
	bool isNextTo(const u16 entity) const;

	/// Returns true if the given entity is adjacent to this entity
	bool isNextTo(S_Entity& entity) const;

	/// Returns true if the given position is within a certain distance
	bool isWithinDistance(const Vec2s& position, int distance) const;

	/// Instructs the entity to move to a point if possible
	void moveToPosition(const Vec2<u16>& position);

	/// Moves the entity one tile closer to the given position
	void stepTowards(const Vec2s& target);

	/// Moves the entity one tile closer to the given entity
	void stepTowards(S_Entity& target);

	/// Instructs the entity to follow the given entity
	void startFollow(const u16 entity);

	/// Instructs the entity to follow the given entity
	void startFollow(S_Entity& entity);

	bool hasUpdate() const;

	void forcePositionUpdate();
};

