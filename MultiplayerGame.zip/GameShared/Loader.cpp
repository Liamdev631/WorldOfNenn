#include "Loader.h"
#include "CSVReader.h"

Loader::Loader()
	: NumberOfItems(7)
{

}

Loader::~Loader()
{

}

void Loader::load()
{
	loadItemsInfo();
	loadEntityInfo();
}

void Loader::loadItemsInfo()
{
	CSVReader reader;
	reader.open("data/ItemData.csv");
	reader.readNextRow(); // Skip header
	for (int i = 0; i < NumberOfItems; i++)
	{
		m_itemNames[i] = reader[1];
		m_itemMaxStack[i] = std::stoi(reader[2]);
		m_itemDescription[i] = reader[3];
		reader.readNextRow();
	}
}

void Loader::loadEntityInfo()
{
	CSVReader reader;
	reader.open("data/EntityData.csv");
	reader.readNextRow(); // Skip header
	for (int i = 0; i < 4; i++)
	{
		m_entityNames[i] = reader[1];
		m_entityDescription[i] = reader[2];
		reader.readNextRow();
	}
}

const std::string& Loader::getItemName(const ItemType& item) const
{
	return m_itemNames[item];
}

const u32& Loader::getItemMaxStack(const ItemType& item) const
{
	return m_itemMaxStack[item];
}

const std::string& Loader::getItemDescription(const ItemType& item) const
{
	return m_itemDescription[item];
}

const std::string& Loader::getEntityName(const EntityType type) const
{
	return m_entityNames[type];
}

const std::string& Loader::getEntityDescription(const EntityType type) const
{
	return m_entityDescription[type];
}
