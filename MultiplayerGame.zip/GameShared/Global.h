#pragma once
#include <stdint.h>
#include <memory>
#include <assert.h>
#include <string>

#define S_TICKS_PER_SECOND 4
#define S_TICK_DURATION (1.0f / S_TICKS_PER_SECOND)

#define MAX_PLAYERS 256
#define MAX_NPCS 256
#define MAX_ENTITIES (MAX_PLAYERS + MAX_NPCS) // Includes players

//#ifdef WIN32
#define PACK #pragma pack(1)
//( __Declaration__ ) __pragma( pack(push, 1) ) __Declaration__ __pragma( pack(pop) )
//#else
//#define PACK( __Declaration__ ) __Declaration__ __attribute__((__packed__))
//#endif

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int16_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;

struct rgba
{
	u8 r, g, b, a;
};

template <typename T>
struct Vec2
{
	T x;
	T y;

	Vec2(T x, T y)
		: x(x), y(y) { }
	Vec2() : x(0), y(0) { }

	Vec2<T> operator*(const T& rhs) { return Vec2((T)(x * rhs), (T)(y * rhs)); }
	Vec2<T> operator/(const T& rhs) { return Vec2((T)(x / rhs), (T)(y / rhs)); }
	Vec2<T> operator-(const Vec2<T>& rhs) { return Vec2((T)(x - rhs.x), (T)(y - rhs.x)); }
	Vec2<T> operator+(const Vec2<T>& rhs) { return Vec2((T)(x + rhs.x), (T)(y + rhs.x)); }

	bool operator==(const Vec2<T>& rhs) const { return x == rhs.x && y == rhs.y; };
	bool operator!=(const Vec2<T>& rhs) const { return x != rhs.x || y != rhs.y; };
};
typedef Vec2<float> Vec2f;
typedef Vec2<u16> Vec2s;

template <typename T>
struct Vec3
{
	T x;
	T y;
	T z;

	Vec3(T x, T y, T z)
		: x(x), y(y), z(z) { }
	Vec3() : x(0), y(0), z(0) { }

	Vec3<T> operator*(const T& rhs) { return Vec3((T)(x * rhs), (T)(y * rhs), (T)(z * rhs)); }
	Vec3<T> operator/(const T& rhs) { return Vec3((T)(x / rhs), (T)(y / rhs), (T)(z * rhs)); }
	Vec3<T> operator/=(const T& rhs) { *this = *this / rhs; return *this; }
	Vec3<T> operator-(const Vec3<T>& rhs) { return Vec3((T)(x - rhs.x), (T)(y - rhs.x), (T)(z - rhs.z)); }
	Vec3<T> operator+(const Vec3<T>& rhs) { return Vec3((T)(x + rhs.x), (T)(y + rhs.x), (T)(z + rhs.z)); }
	Vec3<T>& operator+=(const Vec3<T>& rhs) { *this = *this + rhs; return *this; }
	bool operator==(const Vec3<T>& rhs) { return x == rhs.x && y == rhs.y && z == rhs.z; }
	bool operator!=(const Vec3<T>& rhs) { return x != rhs.x || y != rhs.y || z != rhs.z; }

	float length()
	{
		return sqrtf(x * x + y * y + z * z);
	}
};
typedef Vec3<float> Vec3f;
inline Vec3f cross(const Vec3f& v1, const Vec3f& v2) {
	return Vec3f(v1.y * v2.z - v1.z * v2.y, v1.z * v2.x - v1.x * v2.z, v1.x * v2.y - v1.y * v2.x);
}

enum EntityType : u16
{
	ET_ADMIN = 0,
	ET_PLAYER = 1,
	ET_RAT = 2,
	ET_BIGRAT = 3,
	ET_COUNT
};

enum ItemType : u16
{
	ITEM_BONES = 0,
	ITEM_BRONZE_DAGGER = 1,
	ITEM_BRONZE_SHIELD = 2,
	ITEM_COUNT
};

enum RightClickOption : u8
{
	RCO_NONE = 0,
	RCO_INSPECT = 1,
	RCO_ATTACK = 2,
	RCO_PICKUP = 3,
	RCO_USE = 4,
	RCO_COUNT
};

static const std::string RightClickOptionNames[] =
{
	"None",
	"Inspect",
	"Attack",
	"Pick up",
	"Use,"
};

inline float lerp(float x1, float x2, float t)
{
	return x1 + (x2 - x1) * t;
}

inline Vec2f lerp(Vec2f v1, Vec2f v2, float t)
{
	return v1 + (v2 - v1) * t;
}

struct GameTime
{
	u32 totalTime; // ms
	float deltaTime; // seconds

	void addDeltaTime(float dt)
	{
		deltaTime = dt;
		totalTime += (u32)(1000.f * dt);
	}
};

enum Region : u8
{
	R_Overworld = 0,
	R_Cave1 = 1,
	NUM_REGIONS
};