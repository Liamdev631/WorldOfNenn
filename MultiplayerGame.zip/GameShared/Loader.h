#pragma once
#include "Global.h"
#include <vector>

class Loader
{
private:
	// Items
	u16 NumberOfItems;
	std::string	m_itemNames[7];
	u32			m_itemMaxStack[7];
	std::string	m_itemDescription[7];

	// Entities
	std::string m_entityNames[4];
	std::string m_entityDescription[4];

public:
	Loader();
	~Loader();

	void load();
	const std::string&	getItemName(const ItemType& item) const;
	const u32&			getItemMaxStack(const ItemType& item) const;
	const std::string&	getItemDescription(const ItemType& item) const;
	const std::string& getEntityName(const EntityType type) const;
	const std::string& getEntityDescription(const EntityType type) const;

private:
	void loadItemsInfo();
	void loadEntityInfo();
};