#pragma once
#include "Global.h"
#include "Items.h"
#include "CombatState.h"

typedef u8 packet_header;

/*
This is the first game packet the client should recieve.
*/
#pragma pack(push, 1)
struct SP_Hello
{
	const packet_header header = 0; // 0
	u32 timestamp;
	u16 uid;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_EntityStatus 
{
	const packet_header header = 1; // 1
	u8 numEntities;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_EntityStatus_Elem
{
	u16 uid;
	EntityType entityType;
	Vec2<u16> pos;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_RemoveEntity
{
	const packet_header header = 2; // 2
	u16 uid;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_Inventory
{
	const packet_header header = 3; // 3
	u16 uid;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_EntityTookDamage
{
	const packet_header header = 4; // 4
	u16 defender;
	u8 damage;
	CombatState combatState;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_ItemPicked
{
	const packet_header header = 5; // 5
	DropableItem item;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_ItemDropped
{
	const packet_header header = 6; // 6
	DropableItem item;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct SP_EntityMoved
{
	const packet_header header = 7; // 7
	u16 uid;
	Vec2<u16> pos;
	u8 rotation;
};
#pragma pack(pop)
