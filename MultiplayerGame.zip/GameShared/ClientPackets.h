#pragma once
#include "Global.h"
#include "Items.h"

typedef u8 packet_header;

#pragma pack(push, 1)
#define CP_AttackEntity_header 0
struct CP_AttackEntity
{
	const packet_header header = 0;
	u16 targetUID;
};
#pragma pack(pop)

#pragma pack(push, 1)
#define CP_ItemPicked_header 1

struct CP_ItemPicked
{
	const packet_header header = 1;
	DropableItem item;
};
#pragma pack(pop)

#pragma pack(push, 1)
#define CP_ItemDropped_header 2

struct CP_ItemDropped
{
	const packet_header header = 2;
	DropableItem item;
};
#pragma pack(pop)

#pragma pack(push, 1)
#define CP_EntityMoved_header 3

struct CP_EntityMoved
{
	const packet_header header = 3;
	u16 uid;
	Vec2<u16> pos;
};
#pragma pack(pop)
