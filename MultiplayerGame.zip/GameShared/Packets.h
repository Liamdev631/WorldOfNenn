#pragma once
#include "WPacket.h"
#include "RPacket.h"
#include "ServerPackets.h"
#include "ClientPackets.h"

// Allows for 256 different kinds of packets. This will probably never be changed, but who knows.
typedef u8 packet_header;
