#include "Test.h"

Test::Test(const std::string& name)
	: name(name), failed(false)
{

}

Test::~Test()
{

}

template<typename T>
void Test::printBytes(const T& object) const
{
	u8* buff = reinterpret_cast<u8*>(&object);
	for (size_t i = 0; i < sizeof(T); i++)
		printf("0x%02x ", buff[i]);
	printf("\n");
}

void Test::printBytes(const void* object, const size_t size, const size_t offset) const
{
	for (size_t i = offset; i < offset + size; i++)
		printf("0x%02x ", reinterpret_cast<const char*>(object)[i]);
	printf("\n");
}

void Test::reportFailure(const std::string& failMessage) 
{
	printf("%s\n", failMessage.c_str());
	failed = true;
}

void Test::run() 
{
	printf("\n----- Test '%s'-----\n\n", name.c_str());
	runAllSubtests();
}
